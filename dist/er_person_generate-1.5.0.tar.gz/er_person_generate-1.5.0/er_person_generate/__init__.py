from .altura import altura
from .cpf import cpf
from .data_de_nascimento import dataNascimento
from .nome import nome
from .peso import peso
from .telefone import telefone
from .pessoa_F import pessoaF
from .pessoa_M import pessoaM
